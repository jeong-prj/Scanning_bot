/*
Software License Agreement (BSD License)

Authors : Brighten Lee <shlee@roas.co.kr>

Copyright (c) 2020, ROAS Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ROAS_BASE__ROAS_HAREWARE_H_
#define ROAS_BASE__ROAS_HAREWARE_H_

#include <string>
#include <vector>
#include <cmath>

#include "hardware_interface/joint_command_interface.h"
#include "hardware_interface/joint_state_interface.h"
#include "hardware_interface/robot_hw.h"

#include "roas_base/message_type.h"

using namespace std;

class RoasHardware : public hardware_interface::RobotHW
{
public:
  RoasHardware(vector<string> joint, string robot);

  virtual ~RoasHardware() = default;

  /**
   * \brief Register joint handle and joint state handle
   */
  void registerHardwareInterface();

  /**
   * \brief Write command message to hardware interface
   * \param cmd Command to motor driver
   */
  void writeCommandToHardware(Command& cmd);

  /**
   * \brief Feedaback callback
   * \param msg Motor driver's feedback
   */
  void receiveFeedback(const Feedback& msg);

private:
  /// Hardware interface
  hardware_interface::JointStateInterface joint_state_interface_;
  hardware_interface::VelocityJointInterface velocity_joint_interface_;

  /// Data of joint handles
  vector<double> cmd_, pos_, vel_, eff_;

  /// Robot name
  string robot_;

  /// Joint name
  vector<string> joint_;
};

#endif  // ROAS_BASE__ROAS_HAREWARE_H_