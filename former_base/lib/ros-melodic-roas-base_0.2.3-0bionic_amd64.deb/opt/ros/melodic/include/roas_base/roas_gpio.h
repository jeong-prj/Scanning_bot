/*
Software License Agreement (BSD License)

Authors : Brighten Lee <shlee@roas.co.kr>

Copyright (c) 2021, ROAS Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ROAS_GPIO__ROAS_GPIO_H_
#define ROAS_GPIO__ROAS_GPIO_H_

#include <string>
#include <chrono>
#include <thread>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

#include "ros/ros.h"
#include "roas_serial/serial.h"
#include "realtime_tools/realtime_publisher.h"
#include "std_msgs/Bool.h"
#include "sensor_msgs/Range.h"
#include "sensor_msgs/LaserScan.h"

#include "roas_base/SetLed.h"

using namespace std;

class RoasGPIO
{
public:
  RoasGPIO(ros::NodeHandle& nh, ros::NodeHandle& nh_priv);

  virtual ~RoasGPIO();

  /**
   * \brief Initialize
   */
  void init();

  /**
   * \brief Initial setting for serial communication
   */
  bool connect();

  /**
   * \brief Read message
   */
  void read();

  /**
   * \brief Parse the message
   * \param msg Message read through serial communication
   */
  void parse(const string& msg);

  /**
   * \brief Set the led color and mode
   * \param req Request
   * \param resp Response
   */
  bool setLed(roas_base::SetLed::Request& req, roas_base::SetLed::Response& resp);

  /**
   * \brief Publish the ultrasonic sensor data
   */
  void publish();

private:
  /// ROS parameters
  ros::NodeHandle nh_, nh_priv_;
  vector<realtime_tools::RealtimePublisher<sensor_msgs::Range>> ultrasonic_;
  vector<realtime_tools::RealtimePublisher<sensor_msgs::LaserScan>> scan_;
  vector<realtime_tools::RealtimePublisher<std_msgs::Bool>> digital_io_;

  /// rosservice
  ros::ServiceServer srv_led_;

  /// Serial parameters
  string port_;
  int32_t baud_;
  serial::Serial serial_;

  /// Ultrasonic sensor frame id
  vector<string> ultrasonic_frame_;

  /// For converting range to scan
  bool convert_range_to_scan_;
  size_t angle_resolution_;

  /// Digital IO topic name
  vector<string> digital_io_topic_;

  /// LED control
  string led_color_;
  string led_mode_;

  /// Publish frequency
  double publish_frequency_;
};

#endif  // ROAS_GPIO__ROAS_GPIO_H_