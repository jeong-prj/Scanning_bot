/*
Software License Agreement (BSD License)

Authors : Brighten Lee <shlee@roas.co.kr>

Copyright (c) 2020, ROAS Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ROAS_BASE__MESSAGE_TYPE_H_
#define ROAS_BASE__MESSAGE_TYPE_H_

#include <string>
#include <vector>
#include <array>

using namespace std;

struct RobotState
{
  /// The state of the emergency stop switch on the motor controller
  bool emergency_stop = false;

  /// The voltage from the main battery (V)
  double battery_voltage = 0.0;

  /// The voltage from the charger (V)
  double charging_voltage = 0.0;

  /// The current from the 12V user power (A)
  double user_12v_current = 0.0;

  /// The current from the 24V user power (A)
  double user_24v_current = 0.0;
};

struct MotorState
{
  /// The actual position by the encoder value (rad)
  boost::array<double, 2> position = { 0.0, 0.0 };

  /// The actual velocity measured by the encoder as the actual RPM value (rad/s)
  boost::array<double, 2> velocity = { 0.0, 0.0 };

  /// The current flowing through the motors (A)
  boost::array<double, 2> current = { 0.0, 0.0 };

  /// Internal temperature of the motor controller (C)
  double temperature = 0.0;

  /// The state of the controller fault conditions
  vector<string> fault_flags = { "Not connected" };
};

struct Feedback
{
  string robot;

  /// Robot state
  RobotState robot_state;

  /// Motor state
  vector<MotorState> motor_state;
};

struct Command
{
  vector<double> command;
};

#endif  // ROAS_BASE__MESSAGE_TYPE_H_