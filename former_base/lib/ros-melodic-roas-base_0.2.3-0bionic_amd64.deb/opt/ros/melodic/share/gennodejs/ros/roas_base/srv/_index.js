
"use strict";

let SetLed = require('./SetLed.js')

module.exports = {
  SetLed: SetLed,
};
