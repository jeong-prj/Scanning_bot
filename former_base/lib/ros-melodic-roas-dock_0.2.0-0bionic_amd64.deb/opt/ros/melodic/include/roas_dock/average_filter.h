/*
Software License Agreement (BSD License)

Authors : Brighten Lee <shlee@roas.co.kr>

Copyright (c) 2020, ROAS Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ROAS_DOCK__AVERAGE_FILTER_H_
#define ROAS_DOCK__AVERAGE_FILTER_H_

using namespace std;

class AverageFilter
{
public:
  /**
   * \brief Average Filter
   */
  AverageFilter()
  {
    clear();
  }

  virtual ~AverageFilter() = default;

  /**
   * \brief Add a new data and calculate the cumulative average
   * \param data New input data
   */
  double add(const double data)
  {
    length_ += 1;
    old_weight_ = (static_cast<double>(length_) - 1.0) / static_cast<double>(length_);
    new_weight_ = 1.0 / static_cast<double>(length_);
    average_ = average_ * old_weight_ + data * new_weight_;
    return average_;
  }

  /**
   * \brief Clearing
   */
  void clear()
  {
    average_ = 0.0;
    length_ = 0;
    old_weight_ = 0.0;
    new_weight_ = 0.0;
  }

  /**
   * \brief Return the average data
   */
  double get()
  {
    return average_;
  }

private:
  /// Average of input data
  double average_;

  /// Length of input data list
  size_t length_;

  /// Weight of the previois average and new input data
  double old_weight_, new_weight_;
};

#endif  // ROAS_DOCK__AVERAGE_FILTER_H_