/*
Software License Agreement (BSD License)

Authors : Brighten Lee <shlee@roas.co.kr>

Copyright (c) 2020, ROAS Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ROAS_DOCK__DETECTION_H_
#define ROAS_DOCK__DETECTION_H_

#include <string>
#include <vector>
#include <mutex>
#include <cmath>
#include <angles/angles.h>
#include <boost/shared_ptr.hpp>

#include "ros/ros.h"
#include "tf/transform_broadcaster.h"
#include "tf/transform_datatypes.h"
#include "tf/transform_listener.h"
#include "geometry_msgs/PoseStamped.h"
#include "geometry_msgs/Point.h"
#include "sensor_msgs/LaserScan.h"

#include "roas_dock/average_filter.h"

using namespace std;

class Detection
{
public:
  Detection(ros::NodeHandle& nh, ros::NodeHandle& nh_priv);

  virtual ~Detection() = default;

  /**
   * \brief Initialize the values to initiate detection
   */
  void start();

  /**
   * \brief Stop the detection behavior
   */
  void stop();

  /**
   * \brief Get the target pose
   * \param target_pose Target pose
   * \return Whether or not got the target pose after detecting the docking station
   */
  bool getTargetPose(geometry_msgs::PoseStamped& target);

  /**
   * \brief Execute detection behavior
   * \param scan LaserScan data
   */
  void detect(const sensor_msgs::LaserScan::ConstPtr& scan);

  /**
   * \brief Check to see if docking station is detected
   * \return Whether docking station was detected or not
   */
  bool isDetected()
  {
    return detected_;
  }

  /**
   * \brief Extract vertex from LaserScan data
   * \param scan LaserScan data
   * \param index Index of LaserScan data
   */
  bool extractVertex(const sensor_msgs::LaserScan::ConstPtr& scan, const size_t index);

private:
  mutex mutex_;

  /// ROS parameters
  ros::NodeHandle nh_;
  ros::NodeHandle nh_priv_;

  tf::TransformBroadcaster broadcaster_;
  tf::TransformListener listener_;

  /// Pose variables
  geometry_msgs::PoseStamped starting_pose_;
  geometry_msgs::PoseStamped vertex_pose_;
  geometry_msgs::PoseStamped dock_pose_;

  /// Average filter
  AverageFilter avg_x_;
  AverageFilter avg_y_;
  AverageFilter avg_yaw_;

  /// Progress variables
  bool running_, detected_, init_;

  /// Frame that tracks the robot pose
  string tracking_frame_;

  /// Maximum detection distance
  double max_diatance_;

  /// Offset between vertex and contact point
  double docking_offset_;

  /// Accuracy to detect target
  double detection_accuracy_;

  /// Index of the detection range
  size_t angle_min_idx_, angle_max_idx_;

  /// Difference from the front direction
  double diff_front_;
};

#endif  // ROAS_DOCK__DETECTION_H_