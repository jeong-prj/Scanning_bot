/*
Software License Agreement (BSD License)

Authors : Brighten Lee <shlee@roas.co.kr>

Copyright (c) 2020, ROAS Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ROAS_DOCK__ROAS_DOCK_H_
#define ROAS_DOCK__ROAS_DOCK_H_

#include <chrono>
#include <thread>

#include "ros/ros.h"
#include "actionlib/server/simple_action_server.h"
#include "actionlib/client/simple_action_client.h"
#include "realtime_tools/realtime_publisher.h"
#include "std_msgs/Bool.h"
#include "sensor_msgs/LaserScan.h"

#include "roas_dock/detection.h"
#include "roas_dock/diff_controller.h"
#include "roas_dock/DockAction.h"
#include "roas_dock/UndockAction.h"

using namespace std;

class RoasDock
{
public:
  RoasDock(ros::NodeHandle& nh, ros::NodeHandle& nh_priv);

  virtual ~RoasDock() = default;

  /**
   * \brief Execute the docking aciton server
   * \param goal Docking command
   */
  void dockCallback(const roas_dock::DockGoalConstPtr& goal);

  /**
   * \brief Execute the undocking aciton server
   * \param goal Undoocking command
   */
  void undockCallback(const roas_dock::UndockGoalConstPtr& goal);

  /**
   * \brief LaserScan callback
   * \param msg Lidar sensor data
   */
  void scanCallback(const sensor_msgs::LaserScan::ConstPtr& msg);

  /**
   * \brief Docking signal callback
   * \param msg Docking signal
   */
  void dockedCallback(const std_msgs::Bool::ConstPtr& msg);

  /**
   * \brief Check to see the docking status
   * \param result Result of the dock action server
   * \return Success or not
   */
  bool checkDockStatus(roas_dock::DockResult& result);

  /**
   * \brief Check to see the undocking status
   * \param result Result of the undock action server
   * \return Success or not
   */
  bool checkUndockStatus(roas_dock::UndockResult& result);

  /**
   * \brief Reset flag values related to docking status
   */
  void resetFlags();

  /**
   * \brief Check to see the timeout
   * \return Timeout or not
   */
  bool isTimeout();

private:
  /// Process for detecting docking station
  shared_ptr<Detection> detection_;

  /// Process for differential controller
  shared_ptr<DiffController> controller_;

  /// ROS parameters
  ros::NodeHandle nh_;
  ros::NodeHandle nh_priv_;

  ros::Subscriber sub_docked_, sub_scan_;

  tf::TransformBroadcaster broadcaster_;
  tf::TransformListener listener_;

  /// Action server for docking and undocking
  actionlib::SimpleActionServer<roas_dock::DockAction> dock_server_;
  actionlib::SimpleActionServer<roas_dock::UndockAction> undock_server_;

  /// Control loop rate;
  ros::Rate rate_;

  /// Flag related to docking state
  bool docked_, charging_, cancel_;

  /// For check to see the timeout
  std::chrono::steady_clock::time_point time_stamp_;
  double timeout_sec_;

  /// Parameters for undocking
  double undock_distance_;  // Distance the robot moves to undock [m]
  double undock_heading_;   // Heading the robot rotates to undock [rad]

  /// Parameters for recovery
  double recovery_distance_;  // Distance for recovery [m]
};

#endif  // ROAS_DOCK__ROAS_DOCK_H_