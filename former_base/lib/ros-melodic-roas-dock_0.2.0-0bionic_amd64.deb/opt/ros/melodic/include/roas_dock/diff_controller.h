/*
Software License Agreement (BSD License)

Authors : Brighten Lee <shlee@roas.co.kr>

Copyright (c) 2020, ROAS Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ROAS_DOCK__DIFF_CONTROLLER_H_
#define ROAS_DOCK__DIFF_CONTROLLER_H_

#include <string>
#include <vector>
#include <cmath>
#include <angles/angles.h>

#include "ros/ros.h"
#include "tf/transform_datatypes.h"
#include "tf/transform_listener.h"
#include "realtime_tools/realtime_publisher.h"
#include "geometry_msgs/PoseStamped.h"
#include "geometry_msgs/Twist.h"
#include "nav_msgs/Path.h"

using namespace std;

class DiffController
{
public:
  /**
   * \brief Constructor for differential controller
   * This controller is implemented by referring to the following paper.
   * "A Smooth Control Law for Graceful Motion of
   *  Differential Wheeled Mobile Robots in 2D Environment"
   * by Jong Jin Park and Benjamin Kuipers, ICRA 2011
   */
  DiffController(ros::NodeHandle& nh, ros::NodeHandle& nh_priv);

  virtual ~DiffController() = default;

  /**
   * \brief Behavior for the robot to dock
   * \param target Target pose
   */
  bool dock(const geometry_msgs::PoseStamped& target);

  /**
   * \brief Behavior for the robot to undock
   * \param target_distance Target distance [m]
   * \param target_heading Target heading (yaw) [rad]
   */
  bool undock(const double target_distance, const double target_heading);

  /**
   * \brief Send the stop command and reset the flags
   */
  void stop();

  /**
   * \brief Publish the velocity commmand
   */
  void publishCommand();

  /**
   * \brief Publish the velocity commmand
   * \param command Twist message
   */
  void publishPath();

private:
  /// ROS parameters
  tf::TransformListener listener_;

  realtime_tools::RealtimePublisher<geometry_msgs::Twist> cmd_vel_;
  realtime_tools::RealtimePublisher<nav_msgs::Path> path_;

  /// Parameters for smooth control
  double k1_;           // Ratio of the rate of change in theta to the rate of change in r
  double k2_;           // Higher value of the vehicle converge to the slow manifold more quickly
  double beta_;         // Higher value of beta let the velocity drop more quickly as k increases
  double lambda_;       // Higher value of lambda results in more sharply peaked curve
  double min_linear_;   // Minimum linear velocity of robot
  double max_linear_;   // Maximum linear velocity of robot
  double min_angular_;  // Minimum angular velocity of robot
  double max_angular_;  // Maximum angular velocity of robot

  /// Offset to prevent angular velocity bounce when close to the target
  double offset_;

  /// Starting position of the undocking behavior
  geometry_msgs::PoseStamped starting_pose_;

  /// Flags for the undocking behavior
  bool running_, turning_;
};

#endif  // ROAS_DOCK__DIFF_CONTROLLER_H_